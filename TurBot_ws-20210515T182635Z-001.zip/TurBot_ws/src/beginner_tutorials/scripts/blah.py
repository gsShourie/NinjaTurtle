#! /usr/bin/env python

import actionlib
import rospy
from actionlib_msgs.msg import *
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal, MoveBaseFeedback, MoveBaseResult
from geometry_msgs.msg import Point

rospy.init_node('send_client_goal')

client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
while(not client.wait_for_server(rospy.Duration.from_sec(5.0))):
	rospy.loginfo("Waiting for move base server")

goal = MoveBaseGoal()
goal.target_pose.header.frame_id = "map"   # "map"
#goal.target_pose.pose.position.x =2
#goal.target_pose.pose.position.y = 0

goal.target_pose.pose.position =  Point(1,1,0)

goal.target_pose.pose.orientation.x = 0.0
goal.target_pose.pose.orientation.y = 0.0
goal.target_pose.pose.orientation.z = 0.0
goal.target_pose.pose.orientation.w = 1.0

rospy.loginfo("Sending goal location ...")
client.send_goal(goal)
client.wait_for_result(rospy.Duration(60))

if(client.get_state() ==  GoalStatus.SUCCEEDED):
      rospy.loginfo("You have reached the destination")
else:
      rospy.loginfo("The robot failed to reach the destination")
