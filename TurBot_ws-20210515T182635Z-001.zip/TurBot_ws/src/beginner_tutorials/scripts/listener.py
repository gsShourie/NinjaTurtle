#!/usr/bin/env python
import time
import rospy
from nav_msgs.msg import Odometry
from std_msgs.msg import Empty
import tf
from tf.transformations import euler_from_quaternion
from math import degrees
def to_positive_angle(th):
    while True:
        if th < 0:
            th += 360
        if th > 0:
            ans = th % 360
            return ans
            break

def sub_odom():
    sub = rospy.Subscriber('/odom',Odometry, callback_odom)
def callback_odom(data):
    global x,y,th
    x = data.pose.pose.position.x
    y = data.pose.pose.position.y
    q1 = data.pose.pose.orientation.x
    q2 = data.pose.pose.orientation.y
    q3 = data.pose.pose.orientation.z
    q4 = data.pose.pose.orientation.w
    q = (q1, q2, q3, q4)
    e = euler_from_quaternion(q)
    th = degrees(e[2])
    th = to_positive_angle(th)

x, y, th = 0.0, 0.0, 0.0

rospy.init_node("sub_odom")
rate = rospy.Rate(5)
## Reset odometry
pub = rospy.Publisher('/mobile_base/commands/reset_odometry' ,Empty, queue_size=10)
pub.publish()
time.sleep(1)
if __name__ == '__main__':
    sub_odom()
    while not rospy.is_shutdown():
        print "x:%.2f y:%.2f heading:%.2f"%(x, y, th)
        rate.sleep()

