#! /usr/bin/env python

import time
import rospy
from nav_msgs.msg import Odometry
from geometry_msgs.msg import PoseWithCovarianceStamped
from std_msgs.msg import String
import csv

fields = ['X', 'Y', 'Temperature']
filename = "TempData.csv"
with open(filename, 'w') as csvfile:
    csvwriter = csv.writer(csvfile) 
    csvwriter.writerow(fields)
pose = 0
temp = 0

def Odom_pose(msg):
    global pose 
    pose = msg.pose.pose

def AMCL_pose(msg):
    global pose 
    pose = msg.pose.pose.position

def Temp_data(data):
    global temp 
    temp = data.data
    #rospy.loginfo(rospy.get_caller_id() + 'Temp : %s', data.data)


def listen():
    start = time.time()
    seconds = 2
    while True:
        #rospy.Subscriber('odom', Odometry, Odom_pose)
	rospy.Subscriber('amcl_pose', PoseWithCovarianceStamped, AMCL_pose)
        rospy.Subscriber('chatter', String, Temp_data)
    
        cur = time.time()
        elapse = cur - start
        if elapse >= seconds:
            print pose, temp
	    with open(filename, 'a+') as csvfile:    
 	        csvwriter = csv.writer(csvfile)
	        csvwriter.writerow([pose.x, pose.y, temp])
            break

if __name__ == '__main__':
    try:
        while True:
	    rospy.init_node('check_odometry')
	    listen()
	    print("Breaker")
    except KeyboardInterrupt:
        print("Bantu, it's a sixer")
	pass
    

